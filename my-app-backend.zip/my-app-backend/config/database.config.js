module.exports = {
    url: "mongodb+srv://Admin:nimdA@industrialteamproject-xo3fn.mongodb.net/Industrial_Team_Project?retryWrites=true&w=majority",
    name: "Industrial_Team_Project"
}