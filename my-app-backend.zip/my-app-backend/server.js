const express = require('express');
const bodyParser = require('body-parser');
var MongoClient = require('mongodb').MongoClient;

const dbConfig = require('./config/database.config.js');

const app = express()

app.use(bodyParser.urlencoded({ extended: true }))

app.use(bodyParser.json())

app.listen(8000, () => {
    console.log('Server started!')
});

app.get('/', (req, res) => {
    res.json({"message": "Test application for mongoDB interfacing"});
});

app.get('/api/test', (req, res) => {
    res.json({"message": "Test application for mongoDB interfacing"});
});

async function dbConnect(){
    const client = await MongoClient.connect(dbConfig.url,{useNewUrlParser:true, useUnifiedTopology: true});
    console.log('Connected...');
    const db = client.db(dbConfig.name);
    // const collection = client.db("Industrial_Team_Project").collection("Data");
return client;
}


app.get('/api/069', async (req, res) => {
    const client = await dbConnect();
    let results = await client.db(dbConfig.name).collection("Data").find({drg: '069'}).toArray();
    client.close()
    res.send(results)
})

app.get('/api/252', async (req, res) => {
    const client = await dbConnect();
    let results = await client.db(dbConfig.name).collection("Data").find({drg: '252'}).toArray();
    client.close()
    res.send(results)
})














//const express = require('express');
//const bodyParser = require('body-parser');
//var MongoClient = require('mongodb').MongoClient;
//
//const dbConfig = require('./config/database.config.js');
//
//const app = express()
//
//app.use(bodyParser.urlencoded({ extended: true }))
//
//app.use(bodyParser.json())
//
//app.listen(8000, () => {
//    console.log('Server started!')
//});
//
//app.get('/', (req, res) => {
//    res.json({"message": "Test application for mongoDB interfacing"});
//});
//
//app.get('/api/test', (req, res) => {
//    res.json({"message": "Test application for mongoDB interfacing"});
//});
//
//async function dbConnect(){
//
//    const client = await MongoClient.connect(dbConfig.url,{useNewUrlParser:true, useUnifiedTopology:true});
//        console.log('Connected...');
//        const db = client.db("Industrial_Team_Project");
//        //const collection = client.db("Industrial_Team_Project").collection("Data");
//return db;       
//}
//
//
//app.get('/api/069', async (req, res) => {
//    const db = await dbConnect();
//    let results = await db.collection("Data").find({drg: '069'}).toArray();
//    res.send(results)
//});






































//app.route('/api/069').get((req, res) => {
//    const collection = await dbConnect();
//    let results = await collection.find({drg: '069'}).toArray();
//    res.send(results)
//})



























//const express = require('express');
//const bodyParser = require('body-parser');
//var MongoClient = require('mongodb').MongoClient;
//
//const dbConfig = require('./config/database.config.js');
//
//const app = express()
//
//app.use(bodyParser.urlencoded({ extended: true }))
//app.use(bodyParser.json())
//
//app.listen(8000, () => {
//    console.log('Server started!')
//});
//
//app.get('/', (req, res) => {
//    res.json({"message": "Test application for mongoDB interfacing"});
//});




//  MongoClient.connect(dbConfig.url, function(err, client) {
//     if(err) {
//          console.log('Error occurred while connecting to MongoDB Atlas...\n',err);
//     }
//     console.log('Connected...');
//     const collection = client.db("Industrial_Team_Project").collection("Data");
//     // perform actions on the collection object
//
//     //collection.find().toArray((err, items) => {
//     //   console.log(items)
//     //})
//
//     collection.find({drg: '069'}).toArray((err, items) => {
//        console.log(items)
//      })
//
//
//     client.close();
//  });
//
//
//app.route('/api/cats').get((req, res) => {
//res.send({
//    cats: [{ name: 'lilly' }, { name: 'lucy' }],
//})
//})


//MongoClient.connect(dbConfig.url, function(err, client) {
//    if(err) {
//          console.log('Error occurred while connecting to MongoDB Atlas...\n',err);
//     }
//     console.log('Connected...');
//     const collection = client.db("Industrial_Team_Project").collection("Data");
//     // perform actions on the collection object
//
//     //collection.find().toArray((err, items) => {
//     //   console.log(items)
//     //})
//
//     var item;
//     collection.find({drg: '069'}).toArray((err, items) => {
//         item = items;
//        console.log(items)
//
//      })
//
//
//     
//  
//
//
//    app.route('/api/cats').get((req, res) => {
//    res.send(item)
//    })
//    
//    client.close();
//});



//MongoClient.connect(dbConfig.url, function(err, client) {
//    if(err) {
//          console.log('Error occurred while connecting to MongoDB Atlas...\n',err);
//     }
//     console.log('Connected...');
//     const collection = client.db("Industrial_Team_Project").collection("Data");
//     // perform actions on the collection object
//
//     //collection.find().toArray((err, items) => {
//     //   console.log(items)
//     //})
//
//     var item;
//     collection.find({drg: '069'}).toArray((err, items) => {
//        item = items;
//      })
//
//
//     
//  
//
//
//    app.route('/api/069').get((req, res) => {
//        res.send(item)
//    })
//    
//    client.close();
//});