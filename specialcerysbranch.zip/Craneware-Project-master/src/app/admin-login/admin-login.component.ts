import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-login',
  template: `
    <h1> Hello </h1>
    <p>
      admin-login works!
    </p>
  `,
  styles: []
})
export class AdminLoginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
