module.exports = {
    url: "mongodb://dbAdmin:cw123@178.128.47.93:27017/Craneware?authSource=admin",
    name: "Craneware"
    // url: "mongodb+srv://Admin:nimdA@industrialteamproject-xo3fn.mongodb.net/Industrial_Team_Project?retryWrites=true&w=majority",
    // name: "Industrial_Team_Project"
}